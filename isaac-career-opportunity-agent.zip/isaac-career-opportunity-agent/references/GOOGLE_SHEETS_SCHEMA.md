# Google Sheets Opportunity Tracker Schema

Use one row per unique vacancy. Prefer a single worksheet named `Opportunities`. If the user's existing sheet has different headers, map fields to existing columns and preserve their structure rather than forcing a destructive redesign.

## Recommended columns

| Column | Purpose |
|---|---|
| Opportunity_ID | Stable unique identifier; prefer employer requisition ID, otherwise a deterministic normalized key |
| Date_Found | Date first discovered |
| Date_Checked | Most recent verification date |
| Job_Title | Exact advertised title |
| Company | Employer name |
| Location | City/country or stated eligible region |
| Work_Arrangement | Remote, hybrid, on-site |
| Employment_Type | Full-time, part-time, contract, freelance, internship, trainee |
| Industry | Best-supported industry |
| Posting_Date | Original date posted |
| Closing_Date | Application deadline, if stated |
| Salary | Exact disclosed range or `Not disclosed` |
| Currency | Currency of disclosed compensation |
| Experience_Required | Exact stated requirement |
| Key_Skills | Relevant required skills |
| Candidate_Match_Score | Score out of 100 |
| Match_Band | Strong, Good, Stretch |
| Match_Reason | Short evidence-based explanation |
| Skill_Gaps | Material missing requirements |
| Nigeria_Eligibility | Confirmed, unclear, not eligible |
| Work_Authorization | Stated requirements |
| Age_Requirement | Stated minimum age or `Not stated` |
| Relocation_Sponsorship | Exact stated position |
| Verification_Status | ACTIVE_VERIFIED, NEEDS_VERIFICATION, DATE_UNVERIFIED, CLOSED, SUSPICIOUS—EXCLUDE |
| Verification_Evidence | Short evidence note and source |
| Source_Name | Where found |
| Source_URL | Original listing URL |
| Application_URL | Direct application URL |
| Duplicate_Key | Normalized employer/title/location/requisition key |
| Application_Status | User-controlled pipeline status |
| Application_Date | User-controlled date |
| User_Notes | User-controlled notes |
| Last_Action | Most recent user-approved action |

## Status preservation

`Application_Status`, `Application_Date`, `User_Notes`, and `Last_Action` are user-controlled fields.

Allowed statuses may include `New`, `Interested`, `Preparing`, `Applied`, `Assessment`, `Interview`, `Offer`, `Rejected`, `Withdrawn`, and `On Hold`. Do not replace an existing value just because a new research run finds the same vacancy.

For existing rows:
- Never delete or reorder rows unless explicitly asked.
- Never overwrite non-empty user-controlled fields.
- If a listing closes, update only the research/verification status and date-checked fields, not the user's application status.
- If a duplicate is found, retain the existing row and append the additional source URL to a source-notes field only if that field exists and is safe to update.

## Safe append procedure

1. Read headers and all relevant existing rows.
2. Build a duplicate key from normalized company, title, location, requisition ID, and canonical application URL.
3. Check both exact and likely duplicates.
4. Show the proposed new rows and uncertain matches before writing if the sheet structure is unfamiliar.
5. Append only genuinely new records.
6. Leave user-controlled columns blank for new rows unless the user has explicitly directed otherwise.
7. Read back appended rows and verify values.
8. Report exactly what was added, skipped, or not updated.

If a Sheets API or connector is used, request only the permissions needed to read and append/update approved fields. Do not ask for a user's password or one-time code.
