# Isaac Johnson — Career Profile

This file is the candidate-specific source of truth for the career opportunity research skill. Update it when the candidate confirms new information.

## Confirmed identity and education
- Name: Johnson Isaac
- Nationality: Nigerian
- Education: BSc Computer Science, Benue State University (2019–2024)
- High school: Saint Philips Academy (2012–2018)
- CV contact details are available in the candidate's supplied CV. Do not repeat them in public research reports or store them in a job tracker unless specifically needed and authorized.

## Documented professional experience

### Mobile App Developer — Smart Farming Network (FarmVerse), 2025–Present
The supplied CV states that the candidate:
- Developed and maintained a cross-platform Android/iOS application using React Native, Expo, and Expo Router.
- Integrated Firebase services, REST APIs, Node.js backend services, and third-party integrations.
- Supported authentication, real-time data synchronization, and application functionality.
- Built investor and farmer dashboards, AI-powered messaging features, and a blockchain-enabled in-app wallet.
- Implemented responsive interfaces and worked on performance, reliability, and user experience.

### Mobile App Developer — Mobile Voting App, 2024
The supplied CV states that the candidate:
- Developed a secure mobile voting application using Java for backend logic.
- Implemented voter authentication and real-time vote counting.
- Conducted testing for reliability, accuracy, and security.

### Mobile App Developer — Countdown App, Nigerian Institution of Surveyors, 2023
The supplied CV states that the candidate:
- Designed and developed a countdown application using Android Studio.
- Integrated event reminders and notification features.
- Built a responsive user interface.

## Technical skills listed on the CV
- Mobile: React Native, Expo, Expo Router, cross-platform mobile development.
- Languages: JavaScript (ES6+), TypeScript, Java, Python.
- Backend/APIs: Node.js, RESTful APIs, Firebase Authentication, Firebase Storage, third-party API integration.
- Mobile features: real-time data synchronization, push notification integration, secure transactions, offline data handling.
- Quality: responsive UI development, code reviews, testing, debugging.
- AI-assisted tools: Cursor, ChatGPT, Claude.

## Additional skills confirmed by the candidate
- Data entry.
- Excel.

Do not infer advanced spreadsheet analytics, SQL, Power BI, statistics, or professional data analyst experience unless the candidate later confirms them.

## Career preferences
- Target roles:
  1. React Native Developer
  2. Junior Software Developer
  3. Data Entry Specialist
  4. Data Analyst
  5. Technical Support Specialist
  6. QA Tester
- Employment types: full-time, part-time, contract, freelance, internship, trainee.
- Preferred arrangement: fully remote.
- Primary geography: Nigeria.
- International scope: worldwide remote, subject to explicit country eligibility.
- Relocation: open depending on the opportunity.
- Industries: technology/software, fintech, agritech, startups, general business/operations.
- Default posting window: last 14 days.
- Salary: negotiable depending on role.
- Portfolio/GitHub/LinkedIn links: not supplied yet.

## Research cautions
- The candidate has a BSc and project experience, but do not automatically classify the candidate as senior or mid-level.
- Prioritize junior, entry-level, associate, early-career, and experience-appropriate roles. Include roles requiring more experience only as clearly labelled stretch opportunities.
- For data analyst roles, compare actual requirements against the confirmed skills. Flag missing tools or methods rather than claiming proficiency.
- For QA roles, distinguish manual testing from automation testing and identify any missing frameworks or tools.
- For international roles, verify Nigeria eligibility rather than assuming worldwide access.
- Confirm applicable age, contract, and work eligibility requirements before recommending or facilitating applications.
